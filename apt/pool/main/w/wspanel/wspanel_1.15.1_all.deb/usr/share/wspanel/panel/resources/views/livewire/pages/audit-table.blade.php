<div>{{ $this->table }}</div>
