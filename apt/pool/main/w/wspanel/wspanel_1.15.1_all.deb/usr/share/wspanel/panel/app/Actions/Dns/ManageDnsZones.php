<?php

namespace App\Actions\Dns;

use App\Actions\Mail\ManageMail;
use App\Enums\DnsProvider;
use App\Models\DnsZone;
use App\Models\Site;
use App\Services\Agent\AgentException;
use App\Services\Dns\CloudflareDns;
use App\Services\Dns\DnsAdvisor;
use App\Services\Dns\LocalDns;
use App\Support\CurrentClient;
use App\Support\DomainOwnership;

class ManageDnsZones
{
    public function __construct(private readonly LocalDns $local) {}

    /**
     * Creates the zone at its provider (local) or links an existing one
     * (Cloudflare), optionally filling in the recommended records.
     *
     * @param  array{domain: string, provider: string, nameservers?: list<string>, cloudflare_token?: string|null, recommended?: bool}  $data
     *
     * @throws AgentException
     */
    public function create(array $data): DnsZone
    {
        // A client's zone never covers (or sits inside) another owner's names.
        if (CurrentClient::restricted() && DomainOwnership::takenByAnother($data['domain'], CurrentClient::id())) {
            throw new AgentException('forbidden', __('Doména (nebo její část) patří webu, DNS zóně či poště jiného vlastníka.'), 'panel');
        }
        $provider = DnsProvider::from($data['provider']);
        $attributes = [
            'domain' => $data['domain'],
            'provider' => $provider,
            'site_id' => Site::query()->where('domain', $data['domain'])->value('id'),
        ];
        if ($provider === DnsProvider::Local) {
            $this->local->createZone($data['domain'], $data['nameservers'] ?? DnsAdvisor::defaultNameservers());
        } else {
            $attributes['cloudflare_token'] = $data['cloudflare_token'];
            $attributes['cloudflare_zone_id'] = CloudflareDns::zoneId((string) $data['cloudflare_token'], $data['domain']);
        }
        $zone = DnsZone::create($attributes);
        if ($data['recommended'] ?? false) {
            $this->addRecommended($zone);
        }

        return $zone;
    }

    /**
     * addRecommended() as a background task (RunPanelTask): a provider over
     * HTTP (Cloudflare) answers each record on its own. With the mail's
     * DKIM key when there is one.
     *
     * @return array{message: string, body: string|null}
     */
    public function addRecommendedQueued(DnsZone $zone): array
    {
        $dkim = rescue(fn () => app(ManageMail::class)->dkim($zone->domain, 'get'), null, report: false);
        $added = $this->addRecommended($zone, isset($dkim['name'], $dkim['value']) ? ['name' => $dkim['name'], 'value' => $dkim['value']] : null);

        return ['message' => $added === [] ? __('Nic nechybělo') : __('Doporučené záznamy doplněny'), 'body' => $added === [] ? null : __('Přidáno: ').implode(', ', $added)];
    }

    /**
     * Adds the recommended RRsets that the zone does not have yet; existing
     * ones are never overwritten.
     *
     * @param  array{name: string, value: string}|null  $dkim
     * @return list<string> added "name TYPE"
     */
    public function addRecommended(DnsZone $zone, ?array $dkim = null): array
    {
        $api = $zone->api();
        $existing = collect($api->rrsets($zone->domain))->map(fn ($s) => rtrim($s['name'], '.').'|'.$s['type']);
        $added = [];
        foreach (DnsAdvisor::recommended($zone->domain, $dkim) as $r) {
            if ($existing->contains($r['name'].'|'.$r['type'])) {
                continue;
            }
            $api->set($zone->domain, $r['name'], $r['type'], $r['ttl'], $r['records']);
            $added[] = "{$r['name']} {$r['type']}";
        }

        return $added;
    }

    public function delete(DnsZone $zone, bool $removeAtProvider): void
    {
        if ($removeAtProvider && $zone->provider === DnsProvider::Local) {
            $this->local->deleteZone($zone->domain);
        }
        $zone->delete();
    }
}
