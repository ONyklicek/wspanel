<?php

namespace App\Services\Agent;

use App\Enums\DatabaseEngine;
use App\Enums\SiteMode;
use Illuminate\Support\Facades\Cache;

/**
 * What is installed on the server, as reported by the agent (sys.versions).
 * The panel never assumes — it asks.
 */
class SystemInfo
{
    public function __construct(private readonly AgentClient $agent) {}

    /** @return array<string, mixed> */
    public function versions(): array
    {
        return Cache::remember('agent.sys.versions', 60, fn () => $this->agent->call('sys.versions'));
    }

    /** @return array<string, string> version => label */
    public function phpVersionOptions(): array
    {
        try {
            $php = $this->versions()['php'] ?? [];
        } catch (AgentException) {
            return [];
        }

        return collect($php)
            ->filter(fn (array $v) => $v['installed'])
            ->mapWithKeys(fn (array $v) => [$v['version'] => 'PHP '.$v['version']])
            ->sortKeysDesc()
            ->all();
    }

    /** Units the panel runs on: never stoppable from the UI (the agent refuses too). @return list<string> */
    public function panelUnits(): array
    {
        try {
            return $this->versions()['panel_units'] ?? [];
        } catch (AgentException) {
            return [];
        }
    }

    /** @return list<string> worker types available for a framework */
    public function workerTypes(string $framework): array
    {
        try {
            return $this->versions()['workers'][$framework] ?? [];
        } catch (AgentException) {
            return [];
        }
    }

    /** PHP version built into FrankenPHP (worker mode), e.g. "8.5". */
    public function workerPhpVersion(): ?string
    {
        try {
            return ($this->versions()['worker_php'] ?? '') ?: null;
        } catch (AgentException) {
            return null;
        }
    }

    /**
     * Whether the server has the runtime a site mode needs: an installed PHP
     * (classic), FrankenPHP (worker), a Node or a Python version. When the
     * agent cannot be asked, nothing is hidden: creating the site would then
     * fail with the agent's own message rather than lose an option silently.
     */
    public function modeAvailable(SiteMode $mode): bool
    {
        try {
            $this->versions();
        } catch (AgentException) {
            return true;
        }

        return match ($mode) {
            SiteMode::Classic => $this->phpVersionOptions() !== [],
            SiteMode::Worker => $this->workerPhpVersion() !== null,
            SiteMode::Node => $this->nodeVersionOptions() !== [],
            SiteMode::Python => $this->pythonVersionOptions() !== [],
        };
    }

    /** @return array<string, string> major => label */
    public function nodeVersionOptions(): array
    {
        try {
            $majors = $this->versions()['node'] ?? [];
        } catch (AgentException) {
            return [];
        }

        return collect($majors)->sortDesc()->mapWithKeys(fn (string $v) => [$v => "Node {$v}"])->all();
    }

    /** @return array<string, string> minor => label, newest first */
    public function pythonVersionOptions(): array
    {
        try {
            $minors = $this->versions()['python'] ?? [];
        } catch (AgentException) {
            return [];
        }

        return collect($minors)->sortDesc(SORT_NATURAL)->mapWithKeys(fn (string $v) => [$v => "Python {$v}"])->all();
    }

    /** @return array<string, string> installed minor => its exact version ("3.13" => "3.13.18") */
    public function pythonPatches(): array
    {
        try {
            return (array) ($this->versions()['python_patches'] ?? []);
        } catch (AgentException) {
            return [];
        }
    }

    /** @return list<string> Python versions the server can install (Server → Moduly) */
    public function installablePython(): array
    {
        try {
            return array_values($this->versions()['python_installable'] ?? []);
        } catch (AgentException) {
            return [];
        }
    }

    /** @return list<DatabaseEngine> engines installed on the server */
    public function dbEngines(): array
    {
        try {
            $engines = $this->versions()['db_engines'] ?? [];
        } catch (AgentException) {
            return [];
        }

        return array_values(array_filter(array_map(fn (string $e) => DatabaseEngine::tryFrom($e), $engines)));
    }

    /** @return list<string> installed database tools (phpmyadmin, adminer) */
    public function dbTools(): array
    {
        try {
            return $this->versions()['db_tools'] ?? [];
        } catch (AgentException) {
            return [];
        }
    }

    public function defaultPhpVersion(): ?string
    {
        try {
            return $this->versions()['php_default'] ?? null;
        } catch (AgentException) {
            return null;
        }
    }
}
