<?php

namespace Tests\Feature;

use App\Actions\Sites\ManageGitHub;
use App\Livewire\Pages\IntegrationsPage;
use App\Models\GithubConnection;
use App\Models\Setting;
use App\Models\Site;
use App\Models\User;
use App\Services\GitHub\GitHubApp;
use App\Services\GitHub\GitHubException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Sleep;
use Livewire\Livewire;
use Tests\TestCase;

/** Connecting GitHub with a button: the panel's GitHub App, created from a manifest. */
class GitHubAppTest extends TestCase
{
    use RefreshDatabase;

    private const API = 'https://api.github.com';

    private string $pem = '';

    private string $publicKey;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.url' => 'https://panel.localhost:8443']);
        Sleep::fake(); // the retries' pauses
        $key = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
        openssl_pkey_export($key, $this->pem);
        $this->publicKey = openssl_pkey_get_details($key)['key'];
    }

    private function configureApp(): void
    {
        Setting::put(GitHubApp::SETTING, ['id' => 42, 'slug' => 'wspanel-test', 'client_id' => 'Iv1.abc', 'owner' => 'acme',
            'secret' => Crypt::encryptString(json_encode(['client_secret' => 'shh', 'pem' => $this->pem]))]);
    }

    public function test_the_administrator_sends_the_manifest_to_github(): void
    {
        $this->actingAs(User::factory()->create());

        $r = $this->get('/github/app/create?org=acme-org')->assertOk();

        $state = session('github.app_state');
        $r->assertSee('https://github.com/organizations/acme-org/settings/apps/new?state='.$state, false);
        preg_match('/name="manifest" value="([^"]+)"/', $r->getContent(), $m);
        $manifest = json_decode(html_entity_decode($m[1]), true);
        $this->assertSame(route('github.app.created'), $manifest['redirect_url']);
        $this->assertSame([route('github.callback')], $manifest['callback_urls']);
        $this->assertSame('write', $manifest['default_permissions']['administration']);
        $this->assertArrayNotHasKey('hook_attributes', $manifest, 'no webhook of its own: GitHub would validate its URL and refuse a local panel');
    }

    public function test_only_an_administrator_creates_the_app(): void
    {
        $this->actingAs(User::factory()->forClient()->create());

        $this->get('/github/app/create')->assertForbidden();
        $this->get('/github/app/created?code=abcdefgh&state=x')->assertForbidden();
    }

    public function test_the_credentials_github_returns_are_kept_encrypted(): void
    {
        Http::fake([self::API.'/app-manifests/abcdefgh123/conversions' => Http::response([
            'id' => 42, 'slug' => 'wspanel-panel', 'client_id' => 'Iv1.abc', 'client_secret' => 'shh-secret', 'pem' => $this->pem, 'owner' => ['login' => 'acme'],
        ], 201)]);
        $this->actingAs(User::factory()->create())->withSession(['github.app_state' => 'st4te']);

        $this->get('/github/app/created?code=abcdefgh123&state=st4te')->assertRedirect();

        $app = GitHubApp::configured();
        $this->assertSame(['wspanel-panel', 'Iv1.abc'], [$app->slug, $app->clientId]);
        $raw = (string) DB::table('settings')->where('key', GitHubApp::SETTING)->value('value');
        $this->assertStringNotContainsString('shh-secret', $raw);
        $this->assertStringNotContainsString('PRIVATE KEY', $raw);
        // GitHub refuses the JSON body "[]" ("[] is not a null or object").
        Http::assertSent(fn ($request) => str_ends_with($request->url(), '/conversions') && $request->body() === '');
    }

    public function test_a_busy_github_is_retried_while_handing_over_the_keys(): void
    {
        Http::fake([self::API.'/app-manifests/abcdefgh123/conversions' => Http::sequence()
            ->push(['message' => 'Service Unavailable'], 503)
            ->push(['id' => 42, 'slug' => 'wspanel-panel', 'client_id' => 'Iv1.abc', 'client_secret' => 's', 'pem' => $this->pem, 'owner' => ['login' => 'acme']], 201)]);
        $this->actingAs(User::factory()->create())->withSession(['github.app_state' => 'st']);

        $this->get('/github/app/created?code=abcdefgh123&state=st')->assertRedirectContains('https://github.com/apps/wspanel-panel/installations/new');
    }

    public function test_when_github_stays_down_the_same_code_finishes_it_later(): void
    {
        Http::fake([self::API.'/app-manifests/abcdefgh123/conversions' => Http::sequence()
            ->push([], 503)->push([], 503)->push([], 504)->push([], 503)
            ->push(['id' => 42, 'slug' => 'wspanel-panel', 'client_id' => 'Iv1.abc', 'client_secret' => 's', 'pem' => $this->pem, 'owner' => ['login' => 'acme']], 201)]);
        $this->actingAs(User::factory()->create())->withSession(['github.app_state' => 'st']);

        $this->get('/github/app/created?code=abcdefgh123&state=st')->assertRedirect(IntegrationsPage::url());
        $this->assertNull(GitHubApp::configured());
        $this->get('/integrations')->assertSee('Dokončit vytvoření aplikace')->assertSee('Nezakládejte aplikaci znovu');

        $this->post('/github/app/retry')->assertRedirectContains('https://github.com/apps/wspanel-panel/installations/new');
        $this->assertSame('wspanel-panel', GitHubApp::configured()?->slug);
        $this->assertNull(session('github.app_pending'));
    }

    public function test_finishing_later_is_the_administrators_and_needs_a_live_code(): void
    {
        $this->actingAs(User::factory()->forClient()->create())->withSession(['github.app_pending' => ['code' => 'abcdefgh123', 'until' => time() + 60]]);
        $this->post('/github/app/retry')->assertForbidden();

        $this->actingAs(User::factory()->create())->withSession(['github.app_pending' => ['code' => 'abcdefgh123', 'until' => time() - 1]]);
        $this->post('/github/app/retry')->assertStatus(410);
    }

    public function test_a_client_cannot_put_in_the_keys_of_an_app_of_their_own(): void
    {
        Http::fake([self::API.'/app' => Http::response(['id' => 66, 'slug' => 'evil', 'client_id' => 'Iv1.evil', 'owner' => ['login' => 'evil']])]);
        $this->actingAs(User::factory()->forClient()->create());

        try {
            Livewire::test(IntegrationsPage::class)
                ->call('mountAction', 'existingApp')
                ->set('mountedActions.0.data', ['app_id' => 66, 'client_id' => 'Iv1.evil', 'client_secret' => 'secret-secret-secret-1', 'private_key' => $this->pem])
                ->call('callMountedAction');
        } catch (\Throwable) {
            // refused is the point, however the engine reports it
        }

        $this->assertNull(GitHubApp::configured(), 'the panel\'s app is the administrator\'s');
        Http::assertNothingSent();
    }

    public function test_an_existing_apps_keys_are_checked_with_github_before_they_are_kept(): void
    {
        Http::fake([self::API.'/app' => Http::response(['id' => 77, 'slug' => 'wspanel-mine', 'client_id' => 'Iv1.mine', 'owner' => ['login' => 'acme'], 'html_url' => 'https://github.com/apps/wspanel-mine'])]);

        $app = GitHubApp::createFromCredentials(77, 'Iv1.mine', 'secret-secret-secret-1', $this->pem);

        $this->assertSame('wspanel-mine', GitHubApp::configured()->slug);
        Http::assertSent(function (Request $r) {
            [$h, $p] = explode('.', substr($r->header('Authorization')[0], 7));

            return $r->url() === self::API.'/app' && json_decode(base64_decode(strtr($p, '-_', '+/')), true)['iss'] === '77';
        });

        GitHubApp::forget();
        $this->expectException(GitHubException::class);
        GitHubApp::createFromCredentials(77, 'Iv1.other', 'secret-secret-secret-1', $this->pem);
    }

    public function test_a_return_without_this_sessions_state_is_refused(): void
    {
        Http::fake();
        $this->configureApp();
        $this->actingAs(User::factory()->create())->withSession(['github.app_state' => 'mine', 'github.connect_state' => 'mine']);

        $this->get('/github/app/created?code=abcdefgh123&state=forged')->assertForbidden();
        $this->get('/github/callback?code=abc&installation_id=7&state=forged')->assertForbidden();
        Http::assertNothingSent();
    }

    public function test_connect_sends_the_user_to_install_the_app(): void
    {
        $this->configureApp();
        $this->actingAs(User::factory()->forClient()->create());

        $r = $this->get('/github/connect');

        $r->assertRedirect('https://github.com/apps/wspanel-test/installations/new?state='.session('github.connect_state'));
        $this->assertStringStartsWith('https://github.com/login/oauth/authorize?client_id=Iv1.abc', $this->get('/github/connect?existing=1')->headers->get('Location'));
    }

    public function test_the_callback_connects_only_installations_github_confirms_are_the_users(): void
    {
        $this->configureApp();
        Http::fake([
            'https://github.com/login/oauth/access_token' => Http::response(['access_token' => 'ghu_user']),
            self::API.'/user/installations/7/repositories*' => Http::response(['repositories' => [
                ['full_name' => 'acme/app', 'permissions' => ['admin' => true]],
                ['full_name' => 'acme/payroll', 'permissions' => ['admin' => false, 'pull' => true]],
            ]]),
            self::API.'/user/installations*' => Http::response(['installations' => [
                ['id' => 7, 'app_id' => 42, 'account' => ['login' => 'acme', 'type' => 'Organization']],
                ['id' => 8, 'app_id' => 99, 'account' => ['login' => 'other-app', 'type' => 'User']],
            ]]),
        ]);
        $user = User::factory()->forClient()->create();
        $this->actingAs($user)->withSession(['github.connect_state' => 'st']);

        $this->get('/github/callback?code=c0de&installation_id=7&setup_action=install&state=st')->assertRedirect();

        $c = GithubConnection::query()->sole();
        $this->assertSame([$user->id, 7, 'acme', null], [$c->user_id, $c->installation_id, $c->login, $c->token]);
        $this->assertSame(['acme/app'], $c->repositories, 'only repositories the user administers on GitHub');
        Http::assertSent(fn (Request $r) => $r->url() === 'https://github.com/login/oauth/access_token' && $r['client_secret'] === 'shh' && $r['code'] === 'c0de');
    }

    public function test_an_installation_id_that_is_not_the_users_connects_nothing(): void
    {
        $this->configureApp();
        Http::fake([
            'https://github.com/login/oauth/access_token' => Http::response(['access_token' => 'ghu_user']),
            self::API.'/user/installations*' => Http::response(['installations' => [['id' => 7, 'app_id' => 42, 'account' => ['login' => 'acme', 'type' => 'User']]]]),
        ]);
        $this->actingAs(User::factory()->create())->withSession(['github.connect_state' => 'st']);

        $this->get('/github/callback?code=c0de&installation_id=1234&state=st')->assertRedirect();

        $this->assertSame(0, GithubConnection::query()->count());
    }

    public function test_a_member_who_administers_nothing_in_the_installation_connects_nothing(): void
    {
        $this->configureApp();
        Http::fake([
            'https://github.com/login/oauth/access_token' => Http::response(['access_token' => 'ghu_member']),
            self::API.'/user/installations/7/repositories*' => Http::response(['repositories' => [['full_name' => 'acme/app', 'permissions' => ['admin' => false, 'push' => true]]]]),
            self::API.'/user/installations*' => Http::response(['installations' => [['id' => 7, 'app_id' => 42, 'account' => ['login' => 'acme', 'type' => 'Organization']]]]),
        ]);
        $this->actingAs(User::factory()->forClient()->create())->withSession(['github.connect_state' => 'st']);

        $this->get('/github/callback?code=c0de&installation_id=7&state=st')->assertRedirect();

        $this->assertSame(0, GithubConnection::query()->count());
    }

    public function test_an_app_connection_offers_and_links_only_administered_repositories(): void
    {
        $this->configureApp();
        Http::fake([
            self::API.'/app/installations/7/access_tokens' => Http::response(['token' => 'ghs_installation'], 201),
            self::API.'/installation/repositories*' => Http::response(['repositories' => [['full_name' => 'acme/app', 'private' => true], ['full_name' => 'acme/payroll', 'private' => true]]]),
        ]);
        $user = User::factory()->create();
        $this->actingAs($user);
        $c = GithubConnection::query()->create(['user_id' => $user->id, 'login' => 'acme', 'installation_id' => 7, 'repositories' => ['acme/app']]);
        $site = Site::create(['domain' => 'app.example.com', 'mode' => 'classic', 'framework' => 'laravel', 'php_version' => '8.4', 'status' => 'active']);

        $this->assertSame(['acme/app'], array_keys(app(ManageGitHub::class)->repositories($c)));
        $this->assertSame([], app(ManageGitHub::class)->branches($c, 'acme/payroll'));
        try {
            app(ManageGitHub::class)->link($site, $c, ['repo' => 'acme/payroll', 'branch' => 'main', 'trigger' => 'branch', 'notify' => 'poll']);
            $this->fail('a repository the user does not administer must be refused');
        } catch (GitHubException $e) {
            $this->assertStringContainsString('acme/payroll', $e->getMessage());
        }
        Http::assertNotSent(fn (Request $r) => str_contains($r->url(), '/repos/acme/payroll'));
    }

    public function test_api_calls_use_a_cached_installation_token_signed_by_the_app(): void
    {
        $this->configureApp();
        Http::fake([
            self::API.'/app/installations/7/access_tokens' => Http::response(['token' => 'ghs_installation', 'expires_at' => now()->addHour()->toIso8601String()], 201),
            self::API.'/installation/repositories*' => Http::response(['repositories' => [['full_name' => 'acme/app', 'private' => true]]]),
            self::API.'/repos/acme/app/branches*' => Http::response([['name' => 'main']]),
        ]);
        $user = User::factory()->create();
        $this->actingAs($user);
        $c = GithubConnection::query()->create(['user_id' => $user->id, 'login' => 'acme', 'installation_id' => 7, 'repositories' => ['acme/app']]);

        $this->assertSame(['acme/app' => 'acme/app 🔒'], app(ManageGitHub::class)->repositories($c));
        $c->client()->branches('acme/app');

        Http::assertSentCount(3); // one token for both calls
        Http::assertSent(function (Request $r) {
            if (! str_ends_with($r->url(), '/access_tokens')) {
                return false;
            }
            [$h, $p, $s] = explode('.', substr($r->header('Authorization')[0], 7));
            $sig = base64_decode(strtr($s, '-_', '+/'));

            return openssl_verify("{$h}.{$p}", $sig, $this->publicKey, OPENSSL_ALGO_SHA256) === 1
                && json_decode(base64_decode(strtr($p, '-_', '+/')), true)['iss'] === '42';
        });
        Http::assertSent(fn (Request $r) => str_contains($r->url(), '/installation/repositories') && $r->hasHeader('Authorization', 'Bearer ghs_installation'));
    }

    public function test_disconnecting_leaves_the_installation_others_may_share(): void
    {
        $this->configureApp();
        Http::fake();
        $user = User::factory()->create();
        $other = User::factory()->create();
        GithubConnection::query()->withoutGlobalScope('owner')->create(['user_id' => $other->id, 'login' => 'acme', 'installation_id' => 7, 'repositories' => ['acme/web']]);
        $this->actingAs($user);
        $c = GithubConnection::query()->create(['user_id' => $user->id, 'login' => 'acme', 'installation_id' => 7, 'repositories' => ['acme/app']]);

        app(ManageGitHub::class)->disconnect($c);

        Http::assertNothingSent();
        $this->assertSame(1, GithubConnection::query()->withoutGlobalScope('owner')->count(), 'the other user keeps their connection');
    }

    public function test_the_integrations_page_offers_one_button_for_each_situation(): void
    {
        $this->actingAs(User::factory()->create());
        $this->get('/integrations')->assertOk()->assertSee('Propojit s GitHubem')->assertSee(route('github.app.create'), false);

        $this->actingAs(User::factory()->forClient()->create());
        $this->get('/integrations')->assertOk()->assertSee('zatím nenastavil správce')->assertDontSee(route('github.app.create'), false);

        $this->configureApp();
        $this->get('/integrations')->assertOk()->assertSee(route('github.connect'), false)->assertSee('Nepropojeno');
    }

    public function test_after_creating_the_app_the_administrator_goes_straight_to_installing_it(): void
    {
        Http::fake([self::API.'/app-manifests/abcdefgh123/conversions' => Http::response([
            'id' => 42, 'slug' => 'wspanel-panel', 'client_id' => 'Iv1.abc', 'client_secret' => 's', 'pem' => $this->pem, 'owner' => ['login' => 'acme'],
        ], 201)]);
        $this->actingAs(User::factory()->create())->withSession(['github.app_state' => 'st4te']);

        $r = $this->get('/github/app/created?code=abcdefgh123&state=st4te');

        $r->assertRedirect('https://github.com/apps/wspanel-panel/installations/new?state='.session('github.connect_state'));
    }

    public function test_the_user_comes_back_to_the_page_they_started_from_and_never_elsewhere(): void
    {
        $this->configureApp();
        Http::fake([
            'https://github.com/login/oauth/access_token' => Http::response(['access_token' => 'ghu']),
            self::API.'/user/installations*' => Http::response(['installations' => []]),
        ]);
        $this->actingAs(User::factory()->create());

        $this->get('/github/connect?return=/sites/5/deploy');
        $this->get('/github/callback?code=c&state='.session('github.connect_state'))->assertRedirect('/sites/5/deploy');

        foreach (['https://evil.example/x', '//evil.example/x'] as $evil) {
            $this->get('/github/connect?return='.urlencode($evil));
            $this->assertStringNotContainsString('evil', (string) $this->get('/github/callback?code=c&state='.session('github.connect_state'))->headers->get('Location'));
        }
    }
}
