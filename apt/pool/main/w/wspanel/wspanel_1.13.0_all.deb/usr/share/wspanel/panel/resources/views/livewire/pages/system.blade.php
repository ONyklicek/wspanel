@php($size = fn ($b) => \Illuminate\Support\Number::fileSize((int) $b, 1))
<div class="space-y-6">
    @include('partials.background-jobs')
    @if ($error)
        <x-wire::callout color="danger" :heading="__('Agent neodpovídá')">{{ $error }}</x-wire::callout>
    @endif

    <x-wire::section :heading="__('Veřejná adresa')" :description="__('Kam míří navrhované DNS záznamy (weby, pošta, nameservery). Mění se tlačítkem Veřejná adresa nahoře.')">
        @if ($internal && $seen['ipv4'] !== '')
            <x-wire::callout color="warning" :heading="__('Server je ve vnitřní síti (za NATem)')" class="mb-3">
                {{ __('Záznamy by mířily na :local, ale internet server vidí z :ip. Na routeru přesměrujte porty 80 a 443 (pošta 25, 465, 587, 993; DNS 53) na tento server.', ['local' => $address['ipv4'] ?: '—', 'ip' => $seen['ipv4']]) }}
                <div class="mt-2"><x-wire::button size="xs" wire:click="useSeenAddress" wire:loading.attr="disabled" wire:target="useSeenAddress">{{ __('Použít :ip', ['ip' => $seen['ipv4']]) }}</x-wire::button></div>
            </x-wire::callout>
        @endif
        <dl class="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
            <div><dt class="text-xs text-gray-500">IPv4</dt><dd class="font-mono">{{ $address['ipv4'] ?: '—' }}</dd></div>
            <div><dt class="text-xs text-gray-500">IPv6</dt><dd class="font-mono">{{ $address['ipv6'] ?: '—' }}</dd></div>
        </dl>
    </x-wire::section>

    @if ($settings)
        <x-wire::section :heading="__('Název a čas')">
            <dl class="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
                <div><dt class="text-xs text-gray-500">{{ __('Název serveru') }}</dt><dd class="font-mono">{{ $settings['hostname'] }}</dd></div>
                <div><dt class="text-xs text-gray-500">{{ __('Časové pásmo') }}</dt><dd>{{ $settings['timezone'] ?: '—' }}
                    <span class="text-gray-500">({{ \Illuminate\Support\Carbon::parse($settings['time'])->format('H:i') }})</span></dd></div>
                <div class="sm:col-span-2">
                    <dt class="text-xs text-gray-500">{{ __('Synchronizace času (NTP)') }}</dt>
                    <dd class="flex flex-wrap items-center gap-2">
                        @if ($settings['ntp'])
                            <x-wire::badge :color="$settings['ntp_synchronized'] ? 'success' : 'warning'">{{ $settings['ntp_synchronized'] ? __('zapnuto, čas sedí') : __('zapnuto, zatím nesesynchronizováno') }}</x-wire::badge>
                        @else
                            <x-wire::badge color="danger">{{ __('vypnuto') }}</x-wire::badge>
                        @endif
                        <x-wire::button size="xs" color="gray" outlined wire:click="toggleNtp">{{ $settings['ntp'] ? __('Vypnout') : __('Zapnout') }}</x-wire::button>
                        @unless ($settings['ntp'])
                            <span class="text-xs text-gray-500">{{ __('Bez synchronizace se hodiny rozejdou a přestanou sedět certifikáty, 2FA kódy i podpisy pošty.') }}</span>
                        @endunless
                    </dd>
                </div>
            </dl>
        </x-wire::section>

        <x-wire::section :heading="__('Swap')" :description="__('Odkládací prostor na disku, když dojde paměť. Panel spravuje jen svůj swapový soubor, jiný swap (oddíl) jen ukáže.')">
            @if ($settings['swaps'] === [])
                <p class="text-sm text-gray-500">{{ __('Server nemá žádný swap. Při nedostatku paměti jádro rovnou ukončuje procesy (třeba databázi); 1–2 GB swapu je rozumná pojistka.') }}</p>
            @else
                <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="text-xs text-gray-500"><tr><th class="py-1 pe-3 font-normal">{{ __('Kde') }}</th><th class="py-1 pe-3 font-normal">{{ __('Velikost') }}</th><th class="py-1 pe-3 font-normal">{{ __('Využito') }}</th><th></th></tr></thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-white/5">
                        @foreach ($settings['swaps'] as $s)
                            <tr>
                                <td class="py-1 pe-3 font-mono text-xs">{{ $s['path'] }}</td>
                                <td class="py-1 pe-3">{{ $size($s['size']) }}</td>
                                <td class="py-1 pe-3">{{ $size($s['used']) }}</td>
                                <td class="py-1">@if ($s['managed'])<x-wire::badge color="info">{{ __('panel') }}</x-wire::badge>@endif</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            @endif
            <p class="mt-2 text-xs text-gray-500">{{ __('Swappiness: :n', ['n' => $settings['swappiness'] >= 0 ? $settings['swappiness'] : '—']) }}</p>
        </x-wire::section>
    @endif

    @if ($dns !== [])
        <x-wire::section :heading="__('DNS serveru')" :description="__('Záznamy, které server sám potřebuje, zjištěné ve veřejném DNS. Panel je hlídá a upozorní, když některý přestane platit. Záznamy webů a domén pošty jsou u nich.')">
            <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead class="text-xs text-gray-500"><tr>
                    <th class="py-1 pe-3 font-normal">{{ __('Název') }}</th><th class="py-1 pe-3 font-normal">{{ __('Typ') }}</th>
                    <th class="py-1 pe-3 font-normal">{{ __('Má být') }}</th><th class="py-1 font-normal">{{ __('Stav') }}</th>
                </tr></thead>
                <tbody class="divide-y divide-gray-100 dark:divide-white/5">
                    @foreach ($dns as $r)
                        <tr wire:key="dns-{{ $r['key'] }}" class="align-top">
                            <td class="py-1.5 pe-3 font-mono text-xs break-all">{{ $r['name'] }}</td>
                            <td class="py-1.5 pe-3 font-mono text-xs">{{ $r['type'] }}</td>
                            <td class="py-1.5 pe-3">
                                <span class="font-mono text-xs break-all">{{ $r['want'] }}</span>
                                <p class="text-xs text-gray-500">{{ $r['note'] }}</p>
                            </td>
                            <td class="py-1.5">
                                <x-wire::badge :color="$r['ok'] ? 'success' : 'warning'">{{ $r['ok'] ? __('platí') : __('chybí') }}</x-wire::badge>
                                @if (! $r['ok'] && $r['now'] !== '')
                                    <p class="mt-0.5 font-mono text-xs text-gray-500 break-all">{{ __('teď: :now', ['now' => $r['now']]) }}</p>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
            <div class="mt-3 flex flex-wrap items-center gap-3">
                <x-wire::button size="xs" color="gray" outlined wire:click="refreshDns" wire:loading.attr="disabled" wire:target="refreshDns">{{ __('Zkontrolovat znovu') }}</x-wire::button>
                @if (collect($dns)->contains(fn ($r) => $r['type'] === 'A' && str_starts_with($r['name'], 'ns1.')))
                    <span class="text-xs text-gray-500">{{ __('Nameservery ns1/ns2 leží v doméně, kterou samy obsluhují: u registrátora k nim zadejte i IP adresu (glue záznam).') }}</span>
                @endif
            </div>
        </x-wire::section>
    @endif

    @if ($network)
        <x-wire::section :heading="__('Síť')" :description="__('Jen pro čtení: chybná změna sítě z webové stránky by odřízla cestu zpět. Síť se mění u poskytovatele nebo na serveru.')">
            {{-- On a phone the MAC goes under the interface's name and long IPv6
                 addresses wrap: the table never pushes the page sideways. --}}
            <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead class="text-xs text-gray-500"><tr><th class="py-1 pe-3 font-normal">{{ __('Rozhraní') }}</th><th class="py-1 pe-3 font-normal">{{ __('Stav') }}</th><th class="py-1 pe-3 font-normal">{{ __('Adresy') }}</th><th class="hidden py-1 font-normal sm:table-cell">MAC</th></tr></thead>
                <tbody class="divide-y divide-gray-100 dark:divide-white/5">
                    @foreach ($network['interfaces'] as $i)
                        <tr class="align-top">
                            <td class="py-1 pe-3 font-mono text-xs">{{ $i['name'] }}<span class="block text-gray-500 sm:hidden">{{ $i['mac'] }}</span></td>
                            <td class="py-1 pe-3"><x-wire::badge :color="$i['state'] === 'up' ? 'success' : 'gray'">{{ $i['state'] }}</x-wire::badge></td>
                            <td class="py-1 pe-3 font-mono text-xs break-all">{!! implode('<br>', array_map('e', $i['addresses'])) ?: '—' !!}</td>
                            <td class="hidden py-1 font-mono text-xs text-gray-500 sm:table-cell">{{ $i['mac'] }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
            <p class="mt-3 text-sm break-words">
                {{ __('Výchozí brána:') }} <span class="font-mono text-xs break-all">{{ collect($network['gateways'])->map(fn ($g) => $g['gateway'].' ('.$g['dev'].')')->implode(', ') ?: '—' }}</span>
                · {{ __('DNS servery:') }} <span class="font-mono text-xs break-all">{{ implode(', ', $network['resolvers']) ?: '—' }}</span>
            </p>
        </x-wire::section>
    @endif

    @if ($disks)
        <x-wire::section :heading="__('Zdraví disků (SMART)')" :description="__('Disky samy hlásí, jestli neselhávají: přemapované a čekající sektory, opotřebení SSD, teplota.')">
            @if (! $disks['installed'])
                <div class="flex flex-wrap items-center gap-3 text-sm">
                    <span class="text-gray-500">{{ __('Sledování disků není nainstalované (balíček smartmontools).') }}</span>
                    @if (isset($backgroundJobs['packages']))
                        {{-- Installing: the state where the button was, not only at the top. --}}
                        <span class="inline-flex items-center gap-2 text-primary-700 dark:text-primary-300">
                            {!! icon('outline:arrow-path', 'size-4 animate-spin') !!}
                            {{ __('Instaluje se…') }} <x-panel.elapsed :since="\Illuminate\Support\Carbon::parse($backgroundJobs['packages']['started'])" />
                        </span>
                    @else
                        <x-wire::button size="sm" icon="outline:arrow-down-tray" wire:click="installSmart" wire:loading.attr="disabled" wire:target="installSmart">{{ __('Nainstalovat') }}</x-wire::button>
                    @endif
                </div>
            @elseif ($disks['disks'] === [] || collect($disks['disks'])->every(fn ($d) => ! $d['available']))
                <p class="text-sm text-gray-500">{{ __('Disky stav SMART nehlásí. U virtuálního serveru je to běžné: fyzické disky hlídá poskytovatel.') }}</p>
            @else
                <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                    <thead class="text-xs text-gray-500"><tr><th class="py-1 pe-3 font-normal">{{ __('Disk') }}</th><th class="py-1 pe-3 font-normal">{{ __('Stav') }}</th><th class="py-1 pe-3 font-normal">{{ __('Teplota') }}</th><th class="py-1 pe-3 font-normal">{{ __('V provozu') }}</th><th class="py-1 font-normal">{{ __('Podrobnosti') }}</th></tr></thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-white/5">
                        @foreach ($disks['disks'] as $d)
                            @php($bad = ($d['passed'] ?? true) === false || ($d['reallocated'] ?? 0) > 0 || ($d['pending'] ?? 0) > 0 || ($d['wear_percent'] ?? 0) >= 90)
                            <tr>
                                <td class="py-1 pe-3"><span class="font-mono text-xs">{{ $d['name'] }}</span><br><span class="text-xs text-gray-500">{{ $d['model'] }}{{ $d['capacity'] ? ' · '.$size($d['capacity']) : '' }}</span></td>
                                <td class="py-1 pe-3">
                                    @if ($d['error'] ?? null)
                                        <x-wire::badge color="gray">{{ __('nečitelný') }}</x-wire::badge>
                                    @elseif (! $d['available'])
                                        <x-wire::badge color="gray">{{ __('nehlásí SMART') }}</x-wire::badge>
                                    @else
                                        <x-wire::badge :color="$bad ? 'danger' : 'success'">{{ $bad ? __('pozor') : __('v pořádku') }}</x-wire::badge>
                                    @endif
                                </td>
                                <td class="py-1 pe-3">{{ isset($d['temperature']) ? $d['temperature'].' °C' : '—' }}</td>
                                <td class="py-1 pe-3">{{ isset($d['power_on_hours']) ? \App\Support\Lang::count(intdiv($d['power_on_hours'], 24), ':count den', ':count dny', ':count dní') : '—' }}</td>
                                <td class="py-1 text-xs text-gray-500">
                                    @isset($d['wear_percent']){{ __('opotřebení :n %', ['n' => $d['wear_percent']]) }}@endisset
                                    @isset($d['reallocated']){{ __('přemapované sektory: :n', ['n' => $d['reallocated']]) }}@endisset
                                    @if (($d['pending'] ?? 0) > 0) · {{ __('čekající: :n', ['n' => $d['pending']]) }}@endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
                <p class="mt-2 text-xs text-gray-500">{{ __('Disk se stavem „pozor“ zálohujte a nechte vyměnit, dokud ještě čte.') }}</p>
            @endif
        </x-wire::section>
    @endif
</div>
