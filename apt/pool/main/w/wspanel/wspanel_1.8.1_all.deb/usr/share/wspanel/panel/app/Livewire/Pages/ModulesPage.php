<?php

namespace App\Livewire\Pages;

use App\Actions\Dns\ManageDnsServer;
use App\Actions\Mail\ManageMailHosting;
use App\Actions\Server\ManagePython;
use App\Actions\Server\ModuleMemory;
use App\Actions\Sites\ManageXhprof;
use App\Enums\DatabaseEngine;
use App\Enums\DnsProvider;
use App\Http\Middleware\EnsureTwoFactor;
use App\Livewire\Concerns\TranslatesPageText;
use App\Livewire\Concerns\WatchesBackgroundJobs;
use App\Models\AgentTask;
use App\Models\Client;
use App\Models\Database;
use App\Models\DnsZone;
use App\Models\GameServer;
use App\Models\MailDomain;
use App\Models\Setting;
use App\Services\Agent\AgentException;
use App\Services\Agent\SystemInfo;
use App\Support\Features;
use App\Support\Toast;
use App\Wire\Actions\Action;
use NyonCode\WireForms\Components\Radio;
use NyonCode\WireForms\Components\Select;
use NyonCode\WirePanels\Pages\Page;

/**
 * Optional parts of the panel. Chosen at installation (install.sh), switched
 * here later, like the database engines that can be installed afterwards.
 */
class ModulesPage extends Page
{
    use TranslatesPageText;
    use WatchesBackgroundJobs;

    protected static string $view = 'livewire.pages.modules';

    /** Server-wide settings: administrators only. */
    protected static ?string $permission = 'admin';

    protected ?string $title = 'Moduly';

    protected static ?string $slug = 'modules';

    protected static ?string $navigationLabel = 'Moduly';

    protected static ?string $navigationIcon = 'outline:puzzle-piece';

    protected static ?string $navigationGroup = 'server';

    protected static int $navigationSort = 90;

    public function clientsEnabled(): bool
    {
        return Features::clients();
    }

    public function gamesEnabled(): bool
    {
        return Features::games();
    }

    public function gameCount(): int
    {
        return GameServer::acrossClients()->count();
    }

    public function clientCount(): int
    {
        return Client::query()->count();
    }

    /** @return list<string> */
    public function dbEngines(): array
    {
        return array_map(fn ($e) => $e->getLabel(), rescue(fn () => app(SystemInfo::class)->dbEngines(), [], report: false));
    }

    /** @return list<string> installed Python versions, newest first */
    public function pythonVersions(): array
    {
        return array_values(array_keys(app(SystemInfo::class)->pythonVersionOptions()));
    }

    /** @return list<string> installed Python versions with the exact build, newest first ("Python 3.13.18") */
    public function pythonLabels(): array
    {
        $patches = app(SystemInfo::class)->pythonPatches();

        return array_map(fn (string $v) => 'Python '.($patches[$v] ?? $v), $this->pythonVersions());
    }

    /** @return array<string, string> versions the server can still install */
    private function installablePython(): array
    {
        $system = app(SystemInfo::class);

        return collect($system->installablePython())
            ->diff(array_keys($system->pythonVersionOptions()))
            ->sortDesc(SORT_NATURAL)
            ->mapWithKeys(fn (string $v) => [$v => "Python {$v}"])
            ->all();
    }

    /** Memory the part's services use now (null: the agent cannot tell). */
    public function memory(string $part): ?int
    {
        return app(ModuleMemory::class)->of($part);
    }

    /** All optional parts together, for the line above the cards. */
    public function memoryTotal(): ?int
    {
        $usage = app(ModuleMemory::class)->usage();

        return $usage === [] ? null : array_sum($usage);
    }

    /**
     * Installed and running, but nothing uses it: the memory it takes is
     * what turning it off gives back.
     */
    public function unused(string $part): bool
    {
        return match ($part) {
            'mail' => $this->mailHosting() && ! MailDomain::acrossClients()->exists(),
            'dns' => $this->dnsLocal() && ! DnsZone::query()->where('provider', DnsProvider::Local)->exists(),
            'games' => $this->gamesEnabled() && $this->gameCount() === 0,
            'mariadb', 'postgresql', 'mongodb' => in_array($part, array_map(fn ($e) => $e instanceof DatabaseEngine ? $e->value : (string) $e, app(SystemInfo::class)->dbEngines()), true)
                && ! Database::acrossClients()->where('engine', $part)->exists(),
            default => false,
        };
    }

    public function xhprof(): bool
    {
        return app(ManageXhprof::class)->installed();
    }

    public function dnsLocal(): bool
    {
        return app(ManageDnsServer::class)->installed();
    }

    public function mailHosting(): bool
    {
        return app(ManageMailHosting::class)->installed();
    }

    protected function backgroundJobKeys(): array
    {
        return ['mail-install', 'python', 'xhprof', 'dns'];
    }

    /**
     * Runs a module's install or removal in the background: the agent's
     * refusal (something still uses it) is said at once.
     *
     * @param  callable(): AgentTask  $start
     */
    private function runModuleTask(callable $start, string $failed): void
    {
        try {
            $start();
        } catch (AgentException $e) {
            Toast::error($failed, $e->getMessage());
        }
        $this->loadBackgroundJobs();
    }

    /** The menu gains Pošta, a module its card: a fresh page load shows it. */
    protected function backgroundJobFinished(string $key, bool $ok): void
    {
        if ($ok) {
            $this->redirect(self::url());
        }
    }

    /** The policy is not a module: it stays at the top of the page. */
    protected function headerActions(): array
    {
        return [$this->moduleActions()['twoFactor']];
    }

    /** The modules' own buttons, drawn in each module's card. */
    protected function actions(): array
    {
        return array_values(array_map(fn (Action $a) => $a->size('sm'), array_filter($this->moduleActions(), fn (Action $a) => $a->getName() !== 'twoFactor')));
    }

    public function moduleAction(string $name): ?Action
    {
        return ($this->moduleActions()[$name] ?? null)?->size('sm');
    }

    /** @return array<string, Action> */
    private function moduleActions(): array
    {
        $list = [
            Action::make('installMail')
                ->label(__('Nainstalovat poštu (schránky)'))
                ->icon('outline:inbox-stack')
                ->visible(fn () => ! isset($this->backgroundJobs['mail-install']) && ! app(ManageMailHosting::class)->installed())
                ->requiresConfirmation()
                ->modalDescription(__('Doinstaluje Dovecot (IMAP, POP3, Sieve) a Rspamd (antispam), otevře porty 25, 465, 587, 993, 995 a 4190 a Postfix začne přijímat poštu pro přidané domény. Trvá pár minut.'))
                ->action(function () {
                    try {
                        $this->startBackgroundJob('mail-install', app(ManageMailHosting::class)->install(), [
                            'title' => __('Instalace pošty (schránky)'),
                            'done' => __('Pošta nainstalována'),
                            'body' => __('Přidejte domény v Pošta → Domény a schránky.'),
                        ]);
                    } catch (AgentException $e) {
                        Toast::error(__('Instalace selhala'), $e->getMessage());
                    }
                }),
            Action::make('installPython')
                ->label(fn () => $this->pythonVersions() === [] ? __('Nainstalovat Python') : __('Přidat verzi Pythonu'))
                ->icon('outline:command-line')
                ->visible(fn () => $this->installablePython() !== [])
                ->modalDescription(__('Stáhne uv (správce Pythonu od Astralu, ověřený otiskem) a zvolenou verzi CPythonu do /opt/uv/python. Pak půjde zakládat weby v režimu Python (Django, Flask, FastAPI). Trvá zhruba minutu.'))
                ->form(fn () => [
                    Select::make('version')->label(__('Verze'))->options($this->installablePython())
                        ->default(array_key_first($this->installablePython()))->required()
                        ->rules([fn () => 'in:'.implode(',', array_keys($this->installablePython()))]),
                ])
                ->action(function (array $data) {
                    try {
                        app(ManagePython::class)->install((string) $data['version']);
                    } catch (AgentException $e) {
                        Toast::error(__('Instalace selhala'), $e->getMessage());
                    }
                    $this->loadBackgroundJobs();
                }),
            Action::make('upgradePython')
                ->label(__('Aktualizovat Python'))
                ->icon('outline:arrow-path')
                ->color('gray')
                ->visible(fn () => $this->pythonVersions() !== [])
                ->modalDescription(__('Stáhne nejnovější opravné vydání zvolené verze (např. 3.13.5 → 3.13.18, bezpečnostní opravy). Virtualenvy webů zůstanou, weby na této verzi se restartují na nový interpret (krátce přeruší spojení) a staré sestavení se smaže.'))
                ->form(fn () => [
                    Select::make('version')->label(__('Verze'))
                        ->options(array_combine($this->pythonVersions(), $this->pythonLabels()))
                        ->default($this->pythonVersions()[0] ?? null)->required()
                        ->rules([fn () => 'in:'.implode(',', $this->pythonVersions())]),
                ])
                ->action(function (array $data) {
                    try {
                        app(ManagePython::class)->upgrade((string) $data['version']);
                    } catch (AgentException $e) {
                        Toast::error(__('Aktualizace selhala'), $e->getMessage());
                    }
                    $this->loadBackgroundJobs();
                }),
            Action::make('installXhprof')
                ->label(__('Nainstalovat XHProf + XHGui'))
                ->icon('outline:chart-bar')
                ->visible(fn () => ! app(ManageXhprof::class)->installed())
                ->requiresConfirmation()
                ->modalDescription(__('Profilování PHP: rozšíření XHProf pro všechny verze PHP a XHGui pro prohlížení výsledků. Zapíná se u každého webu zvlášť (Nastavení → Výkon a ladění → XHProf), načte se jen do poolu webů, které ho mají zapnuté.'))
                ->action(function () {
                    try {
                        app(ManageXhprof::class)->install();
                    } catch (AgentException $e) {
                        Toast::error(__('Instalace selhala'), $e->getMessage());
                    }
                    $this->loadBackgroundJobs();
                }),
            Action::make('uninstallMail')
                ->label(__('Odinstalovat poštu'))
                ->icon('outline:trash')
                ->color('gray')
                ->visible(fn () => ! isset($this->backgroundJobs['mail-install']) && app(ManageMailHosting::class)->installed())
                ->requiresConfirmation()
                ->modalDescription(__('Odebere Dovecot, Rspamd a webmail a zavře porty 25, 465, 587, 993, 995 a 4190. Jde jen tehdy, když nezbývá žádná poštovní doména (Pošta → Domény). Weby dál odesílají poštu přes Postfix.'))
                ->action(fn () => $this->runModuleTask(fn () => app(ManageMailHosting::class)->uninstall(), __('Odinstalace nejde'))),
            Action::make('installDns')
                ->label(__('Nainstalovat DNS server'))
                ->icon('outline:globe-alt')
                ->visible(fn () => ! isset($this->backgroundJobs['dns']) && ! $this->dnsLocal())
                ->requiresConfirmation()
                ->modalDescription(__('Nainstaluje PowerDNS (jen autoritativní, žádný překlad cizích domén) a otevře port 53 (TCP i UDP). Zóny pak přidáte v menu Síť → DNS. Trvá zhruba minutu.'))
                ->action(fn () => $this->runModuleTask(fn () => app(ManageDnsServer::class)->install(), __('Instalace selhala'))),
            Action::make('uninstallDns')
                ->label(__('Odinstalovat DNS server'))
                ->icon('outline:trash')
                ->color('gray')
                ->visible(fn () => ! isset($this->backgroundJobs['dns']) && $this->dnsLocal())
                ->requiresConfirmation()
                ->modalDescription(__('Odebere PowerDNS a zavře port 53. Jde jen tehdy, když na serveru nezbývá žádná DNS zóna (Síť → DNS); zóny v Cloudflare zůstávají.'))
                ->action(fn () => $this->runModuleTask(fn () => app(ManageDnsServer::class)->uninstall(), __('Odinstalace nejde'))),
            Action::make('uninstallXhprof')
                ->label(__('Odinstalovat XHProf'))
                ->icon('outline:trash')
                ->color('gray')
                ->visible(fn () => ! isset($this->backgroundJobs['xhprof']) && app(ManageXhprof::class)->installed())
                ->requiresConfirmation()
                ->modalDescription(__('Odebere rozšíření XHProf ze všech verzí PHP a XHGui. Jde jen tehdy, když žádný web nemá profilování zapnuté.'))
                ->action(fn () => $this->runModuleTask(fn () => app(ManageXhprof::class)->uninstall(), __('Odinstalace nejde'))),
            Action::make('removePython')
                ->label(__('Odinstalovat verzi Pythonu'))
                ->icon('outline:trash')
                ->color('gray')
                ->visible(fn () => ! isset($this->backgroundJobs['python']) && $this->pythonVersions() !== [])
                ->modalDescription(__('Smaže zvolenou verzi Pythonu; s poslední verzí odejde i uv. Jde jen tehdy, když na ní neběží žádný web.'))
                ->form(fn () => [
                    Select::make('version')->label(__('Verze'))
                        ->options(array_combine($this->pythonVersions(), $this->pythonLabels()))
                        ->default($this->pythonVersions()[0] ?? null)->required()
                        ->rules([fn () => 'in:'.implode(',', $this->pythonVersions())]),
                ])
                ->action(fn (array $data) => $this->runModuleTask(fn () => app(ManagePython::class)->remove((string) $data['version']), __('Odinstalace nejde'))),
            Action::make('twoFactor')
                ->label(__('Dvoufázové přihlášení'))
                ->icon('outline:lock-closed')
                ->color('gray')
                ->modalDescription(__('Kdo musí mít zapnuté dvoufázové přihlášení (aplikace v telefonu). Uživatel bez něj se po přihlášení dostane jen do profilu, kde si ho nastaví.'))
                ->fillFormUsing(fn () => ['policy' => (string) (Setting::get(EnsureTwoFactor::SETTING) ?? 'none')])
                ->form([
                    Radio::make('policy')->label(__('Vyžadovat'))->options(['none' => __('Nikoho'), 'clients' => __('Klienty'), 'all' => __('Všechny (i správce)')])
                        ->rules(['in:none,clients,all'])->required(),
                ])
                ->action(function (array $data) {
                    Setting::put(EnsureTwoFactor::SETTING, $data['policy']);
                    Toast::success(__('Uloženo'));
                }),
            Action::make('enableGames')
                ->label(__('Zapnout herní servery'))
                ->icon('outline:puzzle-piece')
                ->visible(fn () => ! Features::games())
                ->requiresConfirmation()
                ->modalDescription(__('V menu Hosting přibudou Herní servery (Minecraft, Factorio). Na server se zatím nic neinstaluje: Java a server hry se stáhnou až s prvním herním serverem.'))
                ->action(function () {
                    Features::setGames(true);
                    Toast::success(__('Herní servery zapnuty'));
                    $this->redirect(self::url());
                }),
            Action::make('disableGames')
                ->label(__('Vypnout herní servery'))
                ->icon('outline:puzzle-piece')
                ->color('gray')
                ->visible(fn () => Features::games())
                ->requiresConfirmation()
                ->action(function () {
                    if (GameServer::acrossClients()->exists()) {
                        Toast::error(__('Nejde vypnout'), __('Nejdřív smažte všechny herní servery (Hosting → Herní servery).'));

                        return;
                    }
                    Features::setGames(false);
                    Toast::success(__('Herní servery vypnuty'));
                    $this->redirect(self::url());
                }),
            Action::make('enableClients')
                ->label(__('Zapnout klienty a balíčky'))
                ->icon('outline:user-group')
                ->visible(fn () => ! Features::clients())
                ->requiresConfirmation()
                ->modalDescription(__('V menu Hosting přibudou Klienti a Balíčky; weby, databáze a DNS zóny pak můžete přidělovat klientům, kteří se přihlásí jen ke svým věcem.'))
                ->action(function () {
                    Features::setClients(true);
                    Toast::success(__('Klienti a balíčky zapnuty'));
                    $this->redirect(self::url());
                }),
            Action::make('disableClients')
                ->label(__('Vypnout klienty a balíčky'))
                ->icon('outline:user-group')
                ->color('gray')
                ->visible(fn () => Features::clients())
                ->requiresConfirmation()
                ->action(function () {
                    if (Client::query()->exists()) {
                        Toast::error(__('Nejde vypnout'), __('Nejdřív smažte všechny klienty (Hosting → Klienti).'));

                        return;
                    }
                    Features::setClients(false);
                    Toast::success(__('Klienti a balíčky vypnuty'));
                    $this->redirect(self::url());
                }),
        ];

        return collect($list)->keyBy(fn (Action $a) => $a->getName())->all();
    }
}
