<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('mail_domains', function (Blueprint $table) {
            $table->boolean('webmail')->default(true)->after('client_id');
            $table->boolean('autoconfig')->default(true)->after('webmail');
            $table->json('spam')->nullable()->after('autoconfig');
        });
    }

    public function down(): void
    {
        Schema::table('mail_domains', function (Blueprint $table) {
            $table->dropColumn(['webmail', 'autoconfig', 'spam']);
        });
    }
};
